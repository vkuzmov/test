<?php defined('SYSPATH') OR die('No direct access allowed!');

/**
 * Description of ${name}
 *
 * @author Haralan Dobrev
 */
class ${name} {

	
}
