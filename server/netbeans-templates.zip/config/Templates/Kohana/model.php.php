<?php defined('SYSPATH') OR die('No direct access allowed!'); 

/**
 * Description of ${name} model
 * 
 * Created at: ${date} ${time}
 * 
 * @package ${project.displayName}
 * @category Models
 * @author ${user}
 */
class Model_${name} extends ORM {
	
	
	
}
