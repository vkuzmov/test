<?php defined('SYSPATH') OR die('No direct access allowed!');

/**
 * Description of ${name} controller
 * 
 * Created at: ${date} ${time}
 * 
 * @package ${project.displayName}
 * @category Controllers
 * @author ${user}
 */
class Controller_${name} extends Controller {
	
	
	
}