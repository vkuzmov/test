<?php defined('SYSPATH') OR die('No direct access allowed!'); 

/**
 * ${name} configuration file 
 * 
 * Created at: ${date} ${time}
 * 
 * @package ${project.displayName}
 * @author ${user}
 */

return array(
	
);
