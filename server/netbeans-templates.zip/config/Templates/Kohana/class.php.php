<?php defined('SYSPATH') OR die('No direct access allowed!'); 

/**
 * Description of ${name} class
 * 
 * Created at: ${date} ${time}
 * 
 * @package ${project.displayName}
 * @category Base
 * @author ${user}
 */
class ${name} {
	
}